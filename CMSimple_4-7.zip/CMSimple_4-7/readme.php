<?php
/*
README file for CMSimple 4.0 or higher

========================================== 
         PASSWORT / PASSWORD
========================================== 

PASSWORD for this installation:  
PASSWORT für diese Installation:

           test

!!! Please Change this password immediately !!!
!!! Bitte ändern Sie dieses Passwort sofort !!!

Further informations you get under:
Weitere Informationen erhalten Sie unter:

http://cmsimple.org/

========================================== 
 Passwort vergessen? / forgotten password?
========================================== 

Download the file ./cmsimple/config.php or the config.php from the root of the subsite or secondary language.
Laden Sie die Datei ./cmsimple/config.php oder die config.php aus dem Ordner der Subsite oder Zweitsprache herunter.

Open the file with a code editor and change:
Öffnen Sie die Datei mit einem geeigneten Code Editor und ändern Sie:

$cf['security']['password']="\$P\$BxAqSVtvibGUSTyiCouFJZ5RKzmZn81";

!!! Save the file, encoded as "utf-8 without BOM" !!!
!!! Speichern Sie die Datei in der Codierung "utf-8 ohne BOM" !!!

Upload the file to the webserver. Login with "test" and change your password.
Laden Sie die Datei auf den Internetserver hoch. Sie können sich nun mit "test" enloggen und Ihr Passwort ändern.

Recommended code editor:
Empfohlener Code Editor:

http://notepad-plus-plus.org/

*/
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<title>CMSimple_XH readme file</title>
</head>
<body>
<p style="text-align: center; margin: 60px 0 20px 0;">
Please open this file offline with an text editor, to get the informations.
</p>
<p style="text-align: center; margin: 0;">
Bitte &ouml;ffnen Sie diese Datei offline mit einem Texteditor, um die Informationen zu erhalten.
</p>
</body>
</html>