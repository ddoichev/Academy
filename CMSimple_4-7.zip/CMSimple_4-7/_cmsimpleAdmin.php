<?php 
if (preg_match('/cmsimpleAdmin.php/i', $_SERVER['SCRIPT_NAME'])){die('Access Denied');}

// CMSimple Admin User: 
$cmsimpleAdminUser = 'admin';
?>