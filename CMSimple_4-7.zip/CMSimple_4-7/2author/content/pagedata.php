<?php 
/* utf8-marker = äöüß */ 
################## Data fields ############
$page_data_fields[] = 'url';
$page_data_fields[] = 'last_edit';
$page_data_fields[] = 'description';
$page_data_fields[] = 'keywords';
$page_data_fields[] = 'title';
$page_data_fields[] = 'robots';
$page_data_fields[] = 'heading';
$page_data_fields[] = 'show_heading';
$page_data_fields[] = 'template';
$page_data_fields[] = 'published';
$page_data_fields[] = 'show_last_edit';
$page_data_fields[] = 'linked_to_menu';
$page_data_fields[] = 'header_location';
$page_data_fields[] = 'use_header_location';

################## Recently deleted ############
$temp_data['url'] = 'News02';
$temp_data['last_edit'] = '1316870483';
$temp_data['description'] = '';
$temp_data['keywords'] = '';
$temp_data['title'] = '';
$temp_data['robots'] = '';
$temp_data['heading'] = '';
$temp_data['show_heading'] = '0';
$temp_data['template'] = '0';
$temp_data['published'] = '1';
$temp_data['show_last_edit'] = '0';
$temp_data['linked_to_menu'] = '0';
$temp_data['header_location'] = '';
$temp_data['use_header_location'] = '0';

################## Page Data ############
$page_data[0]['url'] = 'Welcome_to_CMSimple';
$page_data[0]['last_edit'] = '1353511172';
$page_data[0]['description'] = '';
$page_data[0]['keywords'] = '';
$page_data[0]['title'] = '';
$page_data[0]['robots'] = '';
$page_data[0]['heading'] = '';
$page_data[0]['show_heading'] = '';
$page_data[0]['template'] = '';
$page_data[0]['published'] = '';
$page_data[0]['show_last_edit'] = '';
$page_data[0]['linked_to_menu'] = '1';
$page_data[0]['header_location'] = '';
$page_data[0]['use_header_location'] = '';

//----------
?>