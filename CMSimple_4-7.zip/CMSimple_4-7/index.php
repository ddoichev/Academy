<?php /* utf8-marker = äöü */
$pth['folder']['base'] = './';
include('./cmsimple/cms.php');
?>