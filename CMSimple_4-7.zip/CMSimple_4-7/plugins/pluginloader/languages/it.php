<?php // utf8-marker = äöüß

	$pluginloader_tx['menu']['available_plugins'] = "Estensioni: ";
	$pluginloader_tx['menu']['select_plugin'] = "Seleziona estensione ...";
	$pluginloader_tx['menu']['tab_main'] = "Impostazioni principali estensione";
	$pluginloader_tx['menu']['tab_css'] = "Foglio di stile dell'estensione";
	$pluginloader_tx['menu']['tab_stylesheet'] = "Foglio di stile dell'estensione";
	$pluginloader_tx['menu']['tab_config'] = "Configurazione dell'estensione";
	$pluginloader_tx['menu']['tab_language'] = "Lingua dell'estensione";
	$pluginloader_tx['menu']['tab_help'] = "Aiuto estensione";
	$pluginloader_tx['success']['saved'] = "Documento salvato: ";
	$pluginloader_tx['error']['plugin_error'] = "Errore estensione: ";
	$pluginloader_tx['error']['cntopen'] = $tx['error']['cntopen']." ";
	$pluginloader_tx['error']['cntwriteto'] = $tx['error']['cntwriteto']." ";
	$pluginloader_tx['error']['notreadable'] = $tx['error']['notreadable']." ";
	$pluginloader_tx['pluginmanager']['message_plugin_disabled1']="L'estensione";
	$pluginloader_tx['pluginmanager']['message_plugin_disabled2']="e' disabilitato dal Gestore estensioni.";
	$pluginloader_tx['pluginmanager']['button_disable']="disabilita";
	$pluginloader_tx['pluginmanager']['button_enable']="mostra";
	$pluginloader_tx['pluginmanager']['button_hide']="nascondi";
	$pluginloader_tx['pluginmanager']['button_save']="salva dati";
	$pluginloader_tx['pluginmanager']['hint_standard_plugin']="Estensione ordinaria";
	$pluginloader_tx['pluginmanager']['linktext_back_to']="torna a";
	$pluginloader_tx['pluginmanager']['message_data_saved']="Gestore estensioni: <b>dati salvati</b>";
	$pluginloader_tx['pluginmanager']['message_datafile1']="Il documento dati";
	$pluginloader_tx['pluginmanager']['message_datafile2']="non esiste o non è scrivibile.";
	$pluginloader_tx['pluginmanager']['tablehead_plugin']="Estensione:";
	$pluginloader_tx['pluginmanager']['tablehead_disable']="disabilita";
	$pluginloader_tx['pluginmanager']['tablehead_enable']="abilita<br />e nel menu' amministrazione:";
	$pluginloader_tx['pluginmanager']['warning_pluginmanager']="<b>!!! ATTENZIONE !!!</b><br />Disabilitare le estensioni richiamate dal modello pagina puo' mettere fuori uso il sito. A quel punto il sito puo' essere risistemato solo via ftp.";
	$pluginloader_tx['utf-8']['marker'] = "äöü";

?>
